2014-12-10 An SSL certificate was bought from dnsimple.com

http://support.dnsimple.com/articles/ssl-certificates/

The product is called "Comodo EssentialSSL Wildcard certificate" and the common name was

*.spatialtranscriptomics.com

It costed 100$ and is valid for a year.

Our domain was authenticated by dnsimple.com sending an email to admin@spatialtranscriptomics.com that we could access.

/Erik Sjölund

